#! /usr/bin/env python3

import rospy 
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import numpy as np
import math
from tf.transformations import euler_from_quaternion, quaternion_from_euler

class Environment():
    def __init__(self, target_x, target_y):
        rospy.Subscriber('/odom', Odometry, self.odometry_callback)
        rospy.Subscriber('/base_scan', LaserScan, self.laser_callback)
        self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.odometry = Odometry()
        self.laser = LaserScan()
        self.position_robot_x = 0.
        self.position_robot_y = 0.
        self.goal_y = target_y
        self.goal_x = target_x
        rospy.sleep(1)
        
        
    def odometry_callback(self, data):
        self.odometry = data
        self.position_robot_x = data.pose.pose.position.x
        self.position_robot_y = data.pose.pose.position.y
        self.z_dir = data.pose.pose.orientation
        orientation = data.pose.pose.orientation
        orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        _, _, self.yaw = euler_from_quaternion(orientation_list)
        self.goal_angle = math.atan2(self.goal_y - self.position_robot_y, self.goal_x - self.position_robot_x)
    
    def laser_callback(self, data):
        self.laser = data
    
    def step(self, action):
        linear_vel = action[0]
        ang_vel = action[1]
        
        vel_cmd = Twist()
        vel_cmd.linear.x = linear_vel
        vel_cmd.angular.z = ang_vel
        
        self.pub_cmd_vel.publish(vel_cmd)
        
    def shutdown(self):
        rospy.loginfo("Lugar alcancado!!! o/ \o")
        self.pub_cmd_vel.publish(Twist())
    

        
    
        

if __name__ == "__main__":
    rospy.init_node('stage_controller_node', anonymous=False)
    
    correccion = 0
    T = 1
    
    target_x = -3.0
    target_y = 5.0
    
    subtarget1_x = 2.0
    subtarget1_y = 0.0
    subtarget2_x = 2.0
    subtarget2_y = -1.0
    subtarget3_x = 0.0
    subtarget3_y = -1.0
    
    env = Environment(target_x, target_y)
       
    
    min_distance = 0.2
    
    action = np.zeros(2)
    
    r = rospy.Rate(10)
    	
    	
    while not rospy.is_shutdown():
        
        x_robot = env.position_robot_x
        y_robot = env.position_robot_y
        z_robot = env.yaw
        
        distance_robot = math.sqrt((x_robot - target_x)**2 + (y_robot - target_y)**2)
        distance_subtarget1 = math.sqrt((x_robot - subtarget1_x)**2 + (y_robot - subtarget1_y)**2)
        distance_subtarget2 = math.sqrt((x_robot - subtarget2_x)**2 + (y_robot - subtarget2_y)**2)
        distance_subtarget3 = math.sqrt((x_robot - subtarget3_x)**2 + (y_robot - subtarget3_y)**2)
	
        goal_angle = math.atan2(target_y - y_robot, target_x - x_robot)
        subtarget1_angle = math.atan2(subtarget1_y - y_robot, subtarget1_x - x_robot)
        subtarget2_angle = math.atan2(subtarget2_y - y_robot, subtarget2_x - x_robot)
        subtarget3_angle = math.atan2(subtarget3_y - y_robot, subtarget3_x - x_robot)
        
        # Exemplo abaixo ----------------------------------------------------------------
        if distance_robot > min_distance:
            
            if T == 1 and distance_subtarget1 > min_distance:

        	#correccion = goal_angle - z_robot
            	
            	#rospy.loginfo('Target 1 - Aonde estou: X--> %s, ZZ--> %s, Z--> %s', x_robot, subtarget1_angle, z_robot)
            	rospy.loginfo('SubTarget 1 - Aonde estou: C--> %s, ZZ--> %s, Z--> %s', correccion, subtarget1_angle, z_robot)
            	#correccion = subtarget1_angle - z_robot
            	if (z_robot < (subtarget1_angle + 0.005)):
            		correccion = subtarget1_angle + z_robot
            		action[0] = 0.0
            		action[1] = correccion
            		env.step(action)
            	elif (z_robot > (subtarget1_angle + 0.01)):
            		correccion = subtarget1_angle - z_robot
            		action[0] = 0.0
            		action[1] = correccion
            		env.step(action)
            	
            	#rospy.loginfo('Target 1 - Aonde estou: C--> %s, ZZ--> %s, Z--> %s', correccion, subtarget1_angle, z_robot)
            	if (min(env.laser.ranges) < 0.2):
                	action[0] = 0.0
                	action[1] = -0.5
            	else:
                	action[0] = 0.3
                	action[1] = 0.0
		
            	env.step(action)
            	
            	if distance_subtarget1 < min_distance + 0.1:
            		T = 2
            		action[0] = 0.0
            		action[1] = subtarget2_angle - z_robot
            		rospy.loginfo('SubTarget 2 - Z = %s', z_robot)
            		
            #########################################################################################

            elif T == 2 and distance_subtarget2 > min_distance:

        	
            	rospy.loginfo('SubTarget 2 - Aonde estou: X--> %s, Y--> %s, Z--> %s', x_robot, y_robot, z_robot)
            	if subtarget2_angle > 0.1:
            		action[1] = subtarget2_angle - z_robot
            	elif subtarget2_angle < 0.1:
            		action[1] = subtarget2_angle + z_robot
            	
            	if (min(env.laser.ranges) < 0.2):
                	action[0] = 0.0
                	action[1] = -0.5
            	else:
                	action[0] = 0.3
                	action[1] = 0.0
		
            	env.step(action)
            
            
            	
            	if distance_subtarget2 < min_distance + 0.1:
            		T = 3
            		rospy.loginfo('SubTarget 3 - Z = %s', z_robot)
          
          #########################################################################################
          
            elif T == 3 and distance_subtarget3 > min_distance:

        	
            	rospy.loginfo('SubTarget 3 - Aonde estou: X--> %s, Y--> %s, Z--> %s', x_robot, y_robot, z_robot)
            	if z_robot < subtarget3_angle - 0.01:
            		#correccion = (subtarget3_angle + z_robot)
            		correccion = subtarget3_angle
            		action[0] = 0.0
            		action[1] = correccion
            		rospy.loginfo('CorreccionL--> %s', correccion)
            		env.step(action)
            	elif z_robot > subtarget3_angle + 0.01:
            		#correccion = (subtarget3_angle - z_robot)
			            		
            		correccion = subtarget3_angle
            		action[0] = 0.0
            		action[1] = correccion
            		rospy.loginfo('CorreccionR--> %s', correccion)
            		env.step(action)
            	
            	#env.step(action)
            	
            	
            	if (min(env.laser.ranges) < 0.2):
                	action[0] = 0.0
                	action[1] = -0.5
                	#action[1] = correccion
            	else:
                	action[0] = 0.3
                	action[1] = 0.0
			
            	env.step(action)
            	
            	if distance_subtarget3 < min_distance + 0.1:
            		T = 4
            		rospy.loginfo('SubTarget 4 - Z = %s', z_robot)
          
            	
            	

            
            
            
            	
        else:
            env.shutdown()
        # Termino do exemplo--------------------------------------------------------------------------------
        
        # FACA O CODIGO AQUI
            
        r.sleep()
