#! /usr/bin/env python3

import rospy 
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
import numpy as np
import math
from tf.transformations import euler_from_quaternion, quaternion_from_euler

class Environment():
    def __init__(self, target_x, target_y):
        rospy.Subscriber('/odom', Odometry, self.odometry_callback)
        rospy.Subscriber('/base_scan', LaserScan, self.laser_callback)
        self.pub_cmd_vel = rospy.Publisher('/cmd_vel', Twist, queue_size=10)
        self.odometry = Odometry()
        self.laser = LaserScan()
        self.position_robot_x = 0.
        self.position_robot_y = 0.
        self.goal_y = target_y
        self.goal_x = target_x
        rospy.sleep(1)
        
        
    def odometry_callback(self, data):
        self.odometry = data
        self.position_robot_x = data.pose.pose.position.x
        self.position_robot_y = data.pose.pose.position.y
        orientation = data.pose.pose.orientation
        orientation_list = [orientation.x, orientation.y, orientation.z, orientation.w]
        _, _, self.yaw = euler_from_quaternion(orientation_list)
        self.goal_angle = math.atan2(self.goal_y - self.position_robot_y, self.goal_x - self.position_robot_x)
    
    def laser_callback(self, data):
        self.laser = data
    
    def step(self, action):
        linear_vel = action[0]
        ang_vel = action[1]
        
        vel_cmd = Twist()
        vel_cmd.linear.x = linear_vel
        vel_cmd.angular.z = ang_vel
        
        self.pub_cmd_vel.publish(vel_cmd)
        
    def shutdown(self):
        rospy.loginfo("Lugar alcancado!!! o/ \o")
        self.pub_cmd_vel.publish(Twist())
        

if __name__ == "__main__":
    rospy.init_node('stage_controller_node', anonymous=False)
   #
    target_x = -3.0
    target_y = 5.0

    env = Environment(target_x, target_y)
    
    targetalcanzado = 0
    
    target1_x=2
    target1_y=-0.5
    
    target2_x=0
    target2_y=-1
    
    target3_x=-1.7
    target3_y=0.8
    
    target4_x=3
    target4_y=4.5
    
    target5_x=0
    target5_y=6
    
    target6_x=-1.5
    target6_y=4
    
    target2_1_x=-2
    target2_1_y=-1
    
    target8_x=0
    target8_y=0
    
    #
    
    min_distance = 0.3
    
    action = np.zeros(2)
    
    r = rospy.Rate(10)
    
    while not rospy.is_shutdown():
        
        x_robot = env.position_robot_x
        y_robot = env.position_robot_y
        
        distance_robot = math.sqrt((x_robot - target_x)**2 + (y_robot - target_y)**2)
        distance_robot_1=math.sqrt((x_robot - target1_x)**2 + (y_robot - target1_y)**2)
        distance_robot_2=math.sqrt((x_robot - target2_x)**2 + (y_robot - target2_y)**2)
        distance_robot_2_1=math.sqrt((x_robot - target2_1_x)**2 + (y_robot - target2_1_y)**2)
        distance_robot_3=math.sqrt((x_robot - target3_x)**2 + (y_robot - target3_y)**2)
        distance_robot_4=math.sqrt((x_robot - target4_x)**2 + (y_robot - target4_y)**2)
        distance_robot_5=math.sqrt((x_robot - target5_x)**2 + (y_robot - target5_y)**2)
        distance_robot_6=math.sqrt((x_robot - target6_x)**2 + (y_robot - target6_y)**2)
        

        goal_angle = math.atan2(target_y - y_robot, target_x - x_robot)
        goal_angle1 = math.atan2(target1_y - y_robot, target1_x - x_robot)
        goal_angle2 = math.atan2(target2_y - y_robot, target2_x - x_robot)
        goal_angle2_1 = math.atan2(target2_1_y - y_robot, target2_1_x - x_robot)
        goal_angle3 = math.atan2(target3_y - y_robot, target3_x - x_robot)
        goal_angle4 = math.atan2(target4_y - y_robot, target4_x - x_robot)
        goal_angle5 = math.atan2(target5_y - y_robot, target5_x - x_robot)
        goal_angle6 = math.atan2(target6_y - y_robot, target6_x - x_robot)
        
        #Comprobacion de alcance de targets
        if((target1_x+0.3>x_robot>target1_x-0.3)and(target1_y+0.3>y_robot>target1_y-0.3)):
        	targetalcanzado=1	
        if((target2_x+0.3>x_robot>target2_x-0.3)and(target2_y+0.3>y_robot>target2_y-0.3)):
        	targetalcanzado=2
        if((target2_1_x+0.3>x_robot>target2_1_x-0.3)and(target2_1_y+0.3>y_robot>target2_1_y-0.3)):
        	targetalcanzado=2.1
        if((target3_x+0.3>x_robot>target3_x-0.3)and(target3_y+0.3>y_robot>target3_y-0.3)):
        	targetalcanzado=3
        if((target4_x+0.3>x_robot>target4_x-0.3)and(target4_y+0.3>y_robot>target4_y-0.3)):
        	targetalcanzado=4
        if((target5_x+0.3>x_robot>target5_x-0.3)and(target5_y+0.3>y_robot>target5_y-0.3)):
        	targetalcanzado=5
        if((target6_x+0.3>x_robot>target6_x-0.3)and(target6_y+0.3>y_robot>target6_y-0.3)):
        	targetalcanzado=6
        
        
        	
        # Exemplo abaixo ----------------------------------------------------------------
        if distance_robot > min_distance:
            rospy.loginfo('Aonde estou: X--> %s, Y--> %s Targets alcanzados -- %s', x_robot, y_robot,targetalcanzado)
            
            
            if targetalcanzado==0 and not min(env.laser.ranges) < 0.3:
            	correcion=goal_angle1-env.yaw
            	if correcion>0.005:
            		action[0] = 0.3
            		action[1] = -correcion
            	elif correcion<0.005:
            		action[0] = 0.3
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            
            
            elif targetalcanzado==1 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle2-env.yaw
            	if correcion>0.005:
            		action[0] = 0.2
            		action[1] = -correcion
            	elif correcion<-0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            
            elif targetalcanzado==2 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle2_1-env.yaw
            	if correcion>0.005:
            		action[0] = 0.2
            		action[1] = -correcion
            	elif correcion<-0.005:
            		action[0] = 0.2
            		action[1] = -correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            	
            elif targetalcanzado==2.1 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle3-env.yaw
            	if correcion>0.005:
            		action[0] = 0.2
            		action[1] = -correcion
            	elif correcion<-0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            	
            elif targetalcanzado==3 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle4-env.yaw
            	if correcion>0.005:
            		action[0] = 0.3
            		action[1] = correcion
            	elif correcion<-0.005:
            		action[0] = 0.3
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            
            
            elif targetalcanzado==4 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle5-env.yaw
            	if correcion>0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	elif correcion<-0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            
            elif targetalcanzado==5 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle6-env.yaw
            	if correcion>0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	elif correcion<-0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            
            elif targetalcanzado==6 and not min(env.laser.ranges) < 0.2:
            	correcion=goal_angle-env.yaw
            	if correcion>0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	elif correcion<-0.005:
            		action[0] = 0.2
            		action[1] = correcion
            	env.step(action)
            	rospy.sleep(0.0005)
            
            
            
            elif(env.laser.angle_min<135 and min(env.laser.ranges) < 0.2):       
            	if env.yaw<0:
            		action[0] = 0.
            		action[1] = -0.4
            	else:
            		action[0] = 0.
            		action[1] = 0.4
            elif(env.laser.angle_min<135 and min(env.laser.ranges) < 0.2):       
            	if env.yaw>0:
            		action[0] = 0.
            		action[1] = -0.4
            	else:
            		action[0] = 0.
            		action[1] = 0.4
            env.step(action)
        else:
            env.shutdown()
        # Termino do exemplo--------------------------------------------------------------------------------
        
        # FACA O CODIGO AQUI
            
        r.sleep()
